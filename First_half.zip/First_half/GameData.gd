extends Node


var current_round_drawings: Dictionary = {}
var all_round_drawings: Dictionary = {}

var active_round: int = 1
var last_brush_size: int = 10


func clear_drawings() -> void:
	if not current_round_drawings.is_empty():
		active_round += 1

	current_round_drawings.clear()

	if not all_round_drawings.has(active_round):
		all_round_drawings[active_round] = {}


func clear_all_drawings() -> void:
	current_round_drawings.clear()
	all_round_drawings.clear()
	active_round = 1


func save_drawing(
	player_id: int,
	image: Image
) -> void:
	var texture: ImageTexture = (
		ImageTexture.create_from_image(image)
	)

	current_round_drawings[player_id] = texture

	if not all_round_drawings.has(active_round):
		all_round_drawings[active_round] = {}

	var round_drawings: Dictionary = (
		all_round_drawings[active_round]
	)

	round_drawings[player_id] = texture
	all_round_drawings[active_round] = round_drawings


func save_drawing_png(
	player_id: int,
	png_bytes: PackedByteArray
) -> bool:
	var image: Image = Image.new()

	var error: Error = (
		image.load_png_from_buffer(png_bytes)
	)

	if error != OK:
		return false

	save_drawing(
		player_id,
		image
	)

	return true


func get_player_drawing(
	player_id: int,
	round_number: int
) -> Texture2D:
	if not all_round_drawings.has(round_number):
		return null

	var round_drawings: Dictionary = (
		all_round_drawings[round_number]
	)

	if not round_drawings.has(player_id):
		return null

	return round_drawings[player_id] as Texture2D


func set_brush_size(
	new_size: int
) -> void:
	last_brush_size = clampi(
		new_size,
		1,
		50
	)


func get_brush_size() -> int:
	return last_brush_size
