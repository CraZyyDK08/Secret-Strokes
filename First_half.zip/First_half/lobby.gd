extends Control


@onready var game_code_label: Label = (
	$CenterContainer/MainPanel/Menu/GameCodeLabel
)

@onready var players_list: Label = (
	$CenterContainer/MainPanel/Menu/PlayersList
)

@onready var start_game_button: Button = (
	$CenterContainer/MainPanel/Menu/StartGameButton
)

@onready var back_button: Button = (
	$CenterContainer/MainPanel/Menu/BackButton
)


var host_check_enabled: bool = false


func _ready() -> void:
	Network.players_updated.connect(
		_refresh_players
	)

	Network.join_failed.connect(
		_on_join_failed
	)

	game_code_label.text = (
		"GAME CODE: "
		+ Network.game_code
	)

	start_game_button.visible = Network.is_host
	start_game_button.disabled = not Network.is_host

	start_game_button.pressed.connect(
		_on_start_game_pressed
	)

	back_button.pressed.connect(
		_on_back_pressed
	)

	_refresh_players()

	var host_timer: Timer = Timer.new()

	host_timer.wait_time = 2.0
	host_timer.one_shot = true

	host_timer.timeout.connect(
		_enable_host_check
	)

	add_child(host_timer)
	host_timer.start()


func _refresh_players() -> void:
	players_list.text = ""

	if Network.players.is_empty():
		players_list.text = (
			"Venter på spillere..."
		)

		return

	for player_key in Network.players:
		var player_id: int = int(player_key)

		var visible_name: String = (
			_get_display_name(player_id)
		)

		players_list.text += (
			visible_name
			+ "\n"
		)

	_check_if_host_left()


func _get_display_name(
	player_id: int
) -> String:
	var base_name: String = str(
		Network.players.get(
			player_id,
			"Ukendt spiller"
		)
	)

	var matching_ids: Array = []

	for player_key in Network.players:
		var current_player_id: int = int(
			player_key
		)

		var current_name: String = str(
			Network.players[player_key]
		)

		if current_name == base_name:
			matching_ids.append(
				current_player_id
			)

	matching_ids.sort()

	if matching_ids.size() <= 1:
		return base_name

	var duplicate_number: int = (
		matching_ids.find(player_id)
		+ 1
	)

	return (
		base_name
		+ " ["
		+ str(duplicate_number)
		+ "]"
	)


func _enable_host_check() -> void:
	host_check_enabled = true
	_check_if_host_left()


func _check_if_host_left() -> void:
	if not host_check_enabled:
		return

	if Network.is_host:
		return

	if Network.players.is_empty():
		return

	if not Network.players.has(1):
		Network.leave_room()

		get_tree().change_scene_to_file(
			"res://main_menu.tscn"
		)


func _on_start_game_pressed() -> void:
	Network.start_game()


func _on_join_failed(
	message: String
) -> void:
	print(
		"Network error: ",
		message
	)


func _on_back_pressed() -> void:
	Network.leave_room()

	get_tree().change_scene_to_file(
		"res://main_menu.tscn"
	)
