extends Control


@onready var title_label: Label = (
	$VBoxContainer/TitleLabel
)

@onready var timer_label: Label = (
	$VBoxContainer/TimerLabel
)

@onready var drawing_grid: GridContainer = (
	$VBoxContainer/ScrollContainer/DrawingGrid
)

@onready var timer: Timer = $Timer


const DISCUSSION_TIME: int = 60


var time_left: int = DISCUSSION_TIME


func _ready() -> void:
	title_label.text = (
		"DISKUSSIONSRUNDE "
		+ str(Network.current_round)
	)

	timer_label.text = (
		"Tid tilbage: "
		+ str(time_left)
	)

	timer.wait_time = 1.0
	timer.one_shot = false

	timer.timeout.connect(
		_on_timer_timeout
	)

	display_drawings()
	timer.start()


func display_drawings() -> void:
	for child in drawing_grid.get_children():
		child.queue_free()

	var player_count: int = (
		GameData.current_round_drawings.size()
	)

	if player_count == 0:
		var empty_label: Label = Label.new()

		empty_label.text = (
			"Ingen tegninger modtaget"
		)

		drawing_grid.add_child(
			empty_label
		)

		return

	var image_size: Vector2

	if player_count == 1:
		drawing_grid.columns = 1
		image_size = Vector2(480, 360)
	elif player_count == 2:
		drawing_grid.columns = 2
		image_size = Vector2(380, 285)
	elif player_count <= 4:
		drawing_grid.columns = 2
		image_size = Vector2(300, 225)
	else:
		drawing_grid.columns = 3
		image_size = Vector2(220, 165)

	for player_key in GameData.current_round_drawings:
		var player_id: int = int(player_key)

		var texture: Texture2D = (
			GameData.current_round_drawings[player_key]
			as Texture2D
		)

		if texture == null:
			continue

		var card: PanelContainer = (
			PanelContainer.new()
		)

		var card_style: StyleBoxFlat = (
			StyleBoxFlat.new()
		)

		card_style.bg_color = Color(
			0.15,
			0.17,
			0.23,
			0.95
		)

		card_style.corner_radius_top_left = 12
		card_style.corner_radius_top_right = 12
		card_style.corner_radius_bottom_left = 12
		card_style.corner_radius_bottom_right = 12

		card_style.content_margin_left = 12
		card_style.content_margin_top = 12
		card_style.content_margin_right = 12
		card_style.content_margin_bottom = 12

		card.add_theme_stylebox_override(
			"panel",
			card_style
		)

		var vbox: VBoxContainer = (
			VBoxContainer.new()
		)

		var image_rect: TextureRect = (
			TextureRect.new()
		)

		image_rect.texture = texture
		image_rect.expand_mode = (
			TextureRect.EXPAND_IGNORE_SIZE
		)

		image_rect.stretch_mode = (
			TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		)

		image_rect.custom_minimum_size = image_size

		var name_label: Label = Label.new()

		name_label.text = (
			_get_display_name(player_id)
		)

		name_label.horizontal_alignment = (
			HORIZONTAL_ALIGNMENT_CENTER
		)

		name_label.add_theme_font_size_override(
			"font_size",
			18
		)

		vbox.add_child(image_rect)
		vbox.add_child(name_label)

		card.add_child(vbox)
		drawing_grid.add_child(card)


func _get_display_name(
	player_id: int
) -> String:
	var base_name: String = str(
		Network.players.get(
			player_id,
			"Ukendt spiller"
		)
	)

	var matching_ids: Array = []

	for player_key in Network.players:
		var current_player_id: int = int(
			player_key
		)

		var current_name: String = str(
			Network.players[player_key]
		)

		if current_name == base_name:
			matching_ids.append(
				current_player_id
			)

	matching_ids.sort()

	if matching_ids.size() <= 1:
		return base_name

	var duplicate_number: int = (
		matching_ids.find(player_id)
		+ 1
	)

	return (
		base_name
		+ " ["
		+ str(duplicate_number)
		+ "]"
	)


func _on_timer_timeout() -> void:
	time_left -= 1

	timer_label.text = (
		"Tid tilbage: "
		+ str(time_left)
	)

	if time_left > 0:
		return

	timer.stop()

	if Network.is_host:
		Network.end_discussion_phase()
