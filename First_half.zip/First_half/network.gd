extends Node


signal players_updated
signal room_joined
signal join_failed(message: String)
signal start_requested

signal drawing_ready_changed
signal all_players_ready

signal voting_state_changed
signal voting_finished
signal imposter_guess_started(message: String)
signal final_game_result(message: String)


const MAX_PLAYERS: int = 8
const MAX_ROUNDS: int = 3
const REGION: String = "eu"


var player_name: String = "Player"
var fusion_user_id: String = ""

var game_code: String = ""
var room_name: String = ""

var players: Dictionary = {}
var is_host: bool = false


var current_round: int = 1
var current_word: String = ""
var current_hint: String = ""
var imposter_id: int = -1


var drawing_ready: Dictionary = {}
var submitted_drawings: Dictionary = {}

var discussion_phase_requested: bool = false
var discussion_scene_started: bool = false


var voting_votes: Dictionary = {}
var voting_result_id: int = -1
var voting_result_message: String = ""
var imposter_guess_player_id: int = -1


var photon_connection_started: bool = false
var photon_connected: bool = false
var room_operation_started: bool = false


var word_data: Dictionary = {
	"Kat": "Et dyr som mange har som kæledyr",
	"Pizza": "Noget rundt man kan spise",
	"Træ": "Noget der vokser i en skov",
	"Rocket": "Noget der kan flyve ud i rummet",
	"Sol": "Noget man ser på himlen om dagen",
	"Kaffe": "Noget mange drikker om morgenen"
}


func _ready() -> void:
	print("Photon Network autoload loaded")

	Fusion.register_broadcast_receiver(self)

	if not Fusion.connected_to_photon.is_connected(
		_on_connected_to_photon
	):
		Fusion.connected_to_photon.connect(
			_on_connected_to_photon
		)

	if Fusion.has_signal("connection_failed"):
		if not Fusion.connection_failed.is_connected(
			_on_connection_failed
		):
			Fusion.connection_failed.connect(
				_on_connection_failed
			)

	if Fusion.has_signal("player_joined"):
		if not Fusion.player_joined.is_connected(
			_on_player_joined
		):
			Fusion.player_joined.connect(
				_on_player_joined
			)

	if Fusion.has_signal("player_left"):
		if not Fusion.player_left.is_connected(
			_on_player_left
		):
			Fusion.player_left.connect(
				_on_player_left
			)


func _exit_tree() -> void:
	if Fusion.has_method("unregister_broadcast_receiver"):
		Fusion.unregister_broadcast_receiver(self)


# =========================================================
# CREATE GAME
# =========================================================

func create_game(
	display_name: String = "Player"
) -> void:
	player_name = display_name.strip_edges()

	if player_name.is_empty():
		player_name = "Player"

	current_round = 1

	_create_unique_fusion_user_id()

	game_code = generate_game_code()
	room_name = "art-imposter-" + game_code.to_lower()

	is_host = true

	players.clear()
	drawing_ready.clear()
	submitted_drawings.clear()
	voting_votes.clear()

	current_word = ""
	current_hint = ""
	imposter_id = -1

	voting_result_id = -1
	voting_result_message = ""
	imposter_guess_player_id = -1

	photon_connection_started = false
	photon_connected = false
	room_operation_started = false

	discussion_phase_requested = false
	discussion_scene_started = false

	if GameData.has_method("clear_all_drawings"):
		GameData.clear_all_drawings()

	print("Creating Photon room")
	print("Username: ", player_name)
	print("Photon user ID: ", fusion_user_id)
	print("Game code: ", game_code)
	print("Room name: ", room_name)

	_connect_to_photon()


# =========================================================
# JOIN GAME
# =========================================================

func join_game(
	display_name: String,
	requested_game_code: String
) -> void:
	player_name = display_name.strip_edges()

	if player_name.is_empty():
		player_name = "Player"

	current_round = 1

	_create_unique_fusion_user_id()

	game_code = requested_game_code.strip_edges().to_upper()
	room_name = "art-imposter-" + game_code.to_lower()

	is_host = false

	players.clear()
	drawing_ready.clear()
	submitted_drawings.clear()
	voting_votes.clear()

	current_word = ""
	current_hint = ""
	imposter_id = -1

	voting_result_id = -1
	voting_result_message = ""
	imposter_guess_player_id = -1

	photon_connection_started = false
	photon_connected = false
	room_operation_started = false

	discussion_phase_requested = false
	discussion_scene_started = false

	if GameData.has_method("clear_all_drawings"):
		GameData.clear_all_drawings()

	print("Joining Photon room")
	print("Username: ", player_name)
	print("Photon user ID: ", fusion_user_id)
	print("Game code: ", game_code)
	print("Room name: ", room_name)

	_connect_to_photon()


# =========================================================
# UNIQUE PHOTON USER ID
# =========================================================

func _create_unique_fusion_user_id() -> void:
	var safe_player_name: String = player_name.replace(
		" ",
		"_"
	)

	fusion_user_id = (
		safe_player_name
		+ "__"
		+ str(OS.get_process_id())
		+ "__"
		+ str(Time.get_ticks_usec())
	)

	print(
		"Generated Fusion user ID: ",
		fusion_user_id
	)


# =========================================================
# CONNECTION
# =========================================================

func _connect_to_photon() -> void:
	if photon_connected:
		_open_room()
		return

	if photon_connection_started:
		return

	photon_connection_started = true

	print(
		"Connecting to Photon as: ",
		fusion_user_id
	)

	Fusion.connect_to_photon.call_deferred(
		fusion_user_id,
		REGION
	)


func _on_connected_to_photon() -> void:
	print("Connected to Photon")

	photon_connected = true

	_open_room()


func _open_room() -> void:
	if room_operation_started:
		return

	room_operation_started = true

	var room_options: FusionRoomOptions = (
		FusionRoomOptions.new()
	)

	room_options.max_players = MAX_PLAYERS

	if is_host:
		Fusion.create_room(
			room_name,
			room_options
		)
	else:
		Fusion.join_room(
			room_name,
			room_options
		)


# =========================================================
# PLAYERS
# =========================================================

func _on_player_joined(
	player_id: int,
	user_id: String
) -> void:
	var visible_name: String = ""

	if not user_id.is_empty():
		visible_name = (
			_get_display_name_from_user_id(user_id)
		)

	if visible_name.is_empty():
		if players.has(player_id):
			visible_name = str(
				players[player_id]
			)
		else:
			visible_name = "Player"

	players[player_id] = visible_name

	if is_host:
		drawing_ready[player_id] = false

	print(
		"Player joined. ID: ",
		player_id,
		" Name: ",
		visible_name
	)

	players_updated.emit()
	room_joined.emit()

	if is_host:
		_broadcast_players_snapshot()
	else:
		call_deferred(
			"_register_username_with_host"
		)


func _on_player_left(
	player_id: int,
	_is_inactive: bool
) -> void:
	print(
		"Player left. ID: ",
		player_id
	)

	players.erase(player_id)
	drawing_ready.erase(player_id)
	submitted_drawings.erase(player_id)
	voting_votes.erase(player_id)

	players_updated.emit()

	if is_host:
		_broadcast_players_snapshot()
		_broadcast_drawing_ready_snapshot()


# =========================================================
# USERNAME REGISTRATION
# =========================================================

func _register_username_with_host() -> void:
	if is_host:
		return

	var local_player_id: int = (
		Fusion.get_local_player_id()
	)

	print(
		"Registering username with host: ",
		player_name
	)

	Fusion.rpc_to(
		Fusion.TARGET_MASTER,
		_receive_username_registration,
		local_player_id,
		player_name
	)


@rpc("any_peer", "reliable")
func _receive_username_registration(
	player_id: int,
	received_username: String
) -> void:
	if not is_host:
		return

	if not players.has(player_id):
		return

	var clean_username: String = (
		received_username.strip_edges()
	)

	if clean_username.is_empty():
		clean_username = "Player"

	players[player_id] = clean_username

	print(
		"Username registered. Player ",
		player_id,
		": ",
		clean_username
	)

	_broadcast_players_snapshot()

	_send_players_snapshot_to_player(
		player_id
	)


# =========================================================
# PLAYER SNAPSHOT
# =========================================================

func _broadcast_players_snapshot() -> void:
	var player_ids: Array = []
	var player_names: Array = []

	for player_key in players:
		player_ids.append(int(player_key))
		player_names.append(str(players[player_key]))

	Fusion.rpc(
		_receive_players_snapshot,
		player_ids,
		player_names
	)


func _send_players_snapshot_to_player(
	target_player_id: int
) -> void:
	var player_ids: Array = []
	var player_names: Array = []

	for player_key in players:
		player_ids.append(int(player_key))
		player_names.append(str(players[player_key]))

	Fusion.rpc_to_player(
		target_player_id,
		_receive_players_snapshot,
		player_ids,
		player_names
	)


@rpc("authority", "call_local")
func _receive_players_snapshot(
	player_ids: Array,
	player_names: Array
) -> void:
	var local_player_id: int = -1
	var local_player_name: String = player_name

	if photon_connected:
		local_player_id = int(
			Fusion.get_local_player_id()
		)

		if players.has(local_player_id):
			local_player_name = str(
				players[local_player_id]
			)

	var received_players: Dictionary = {}

	var amount: int = mini(
		player_ids.size(),
		player_names.size()
	)

	for index in range(amount):
		var player_id: int = int(
			player_ids[index]
		)

		var visible_name: String = str(
			player_names[index]
		)

		if visible_name.is_empty():
			if player_id == local_player_id:
				visible_name = local_player_name
			else:
				visible_name = "Player"

		received_players[player_id] = visible_name

	if not is_host:
		if local_player_id >= 0:
			if not received_players.has(local_player_id):
				received_players[local_player_id] = (
					local_player_name
				)

	players = received_players

	print(
		"Received player snapshot: ",
		players
	)

	players_updated.emit()


# =========================================================
# START GAME OG ROLLER
# =========================================================

func start_game() -> void:
	if not is_host:
		return

	if players.size() < 2:
		print("At least two players are required")
		return

	_choose_word_and_imposter()


func _choose_word_and_imposter() -> void:
	var available_words: Array = word_data.keys()

	var selected_word: String = str(
		available_words.pick_random()
	)

	var selected_hint: String = str(
		word_data[selected_word]
	)

	var player_ids: Array = players.keys()

	var imposter_index: int = randi_range(
		0,
		player_ids.size() - 1
	)

	current_word = selected_word
	current_hint = selected_hint
	imposter_id = int(
		player_ids[imposter_index]
	)

	var local_player_id: int = (
		Fusion.get_local_player_id()
	)

	for player_key in player_ids:
		var player_id: int = int(player_key)

		var player_is_imposter: bool = (
			player_id == imposter_id
		)

		var word_for_player: String = ""
		var hint_for_player: String = ""

		if player_is_imposter:
			hint_for_player = current_hint
		else:
			word_for_player = current_word

		if player_id == local_player_id:
			_apply_private_role(
				player_is_imposter,
				word_for_player,
				hint_for_player
			)
		else:
			Fusion.rpc_to_player(
				player_id,
				_receive_private_role,
				player_is_imposter,
				word_for_player,
				hint_for_player
			)


@rpc("authority", "call_local")
func _receive_private_role(
	new_is_imposter: bool,
	new_word: String,
	new_hint: String
) -> void:
	_apply_private_role(
		new_is_imposter,
		new_word,
		new_hint
	)


func _apply_private_role(
	new_is_imposter: bool,
	new_word: String,
	new_hint: String
) -> void:
	RoleGameManager.apply_server_role(
		new_is_imposter,
		new_word,
		new_hint
	)

	get_tree().change_scene_to_file(
		"res://role_card.tscn"
	)


# =========================================================
# TEGNEFASE
# =========================================================

func start_drawing_phase() -> void:
	if not is_host:
		return

	_reset_drawing_round_state()

	Fusion.rpc(
		_receive_drawing_phase
	)


@rpc("authority", "call_local")
func _receive_drawing_phase() -> void:
	_reset_drawing_round_state()

	get_tree().change_scene_to_file(
		"res://tegne_program.tscn"
	)


func _reset_drawing_round_state() -> void:
	submitted_drawings.clear()
	drawing_ready.clear()

	discussion_phase_requested = false
	discussion_scene_started = false

	GameData.clear_drawings()


# =========================================================
# TEGNINGER OG KLAR-STATUS
# =========================================================

func submit_drawing(
	image: Image
) -> void:
	var png_bytes: PackedByteArray = (
		image.save_png_to_buffer()
	)

	var local_player_id: int = (
		Fusion.get_local_player_id()
	)

	if is_host:
		_receive_drawing_submission(
			local_player_id,
			png_bytes
		)
	else:
		Fusion.rpc_to(
			Fusion.TARGET_MASTER,
			_receive_drawing_submission,
			local_player_id,
			png_bytes
		)


@rpc("any_peer", "reliable")
func _receive_drawing_submission(
	player_id: int,
	png_bytes: PackedByteArray
) -> void:
	if not is_host:
		return

	if not players.has(player_id):
		return

	submitted_drawings[player_id] = png_bytes
	drawing_ready[player_id] = true

	_broadcast_drawing_ready_snapshot()

	if _are_all_players_ready() and not discussion_phase_requested:
		discussion_phase_requested = true
		_broadcast_drawings_and_start_discussion()


func set_local_drawing_ready(
	new_ready_state: bool
) -> void:
	if new_ready_state:
		return

	var local_player_id: int = (
		Fusion.get_local_player_id()
	)

	if is_host:
		_receive_drawing_ready_request(
			local_player_id,
			false
		)
	else:
		Fusion.rpc_to(
			Fusion.TARGET_MASTER,
			_receive_drawing_ready_request,
			local_player_id,
			false
		)


@rpc("any_peer", "reliable")
func _receive_drawing_ready_request(
	player_id: int,
	new_ready_state: bool
) -> void:
	if not is_host:
		return

	if not players.has(player_id):
		return

	drawing_ready[player_id] = new_ready_state

	if not new_ready_state:
		submitted_drawings.erase(player_id)

	_broadcast_drawing_ready_snapshot()


func _broadcast_drawing_ready_snapshot() -> void:
	var player_ids: Array = []
	var ready_states: Array = []

	for player_key in players:
		player_ids.append(int(player_key))

		var player_is_ready: bool = bool(
			drawing_ready.get(
				player_key,
				false
			)
		)

		ready_states.append(player_is_ready)

	Fusion.rpc(
		_receive_drawing_ready_snapshot,
		player_ids,
		ready_states
	)


@rpc("authority", "call_local")
func _receive_drawing_ready_snapshot(
	player_ids: Array,
	ready_states: Array
) -> void:
	drawing_ready.clear()

	var amount: int = mini(
		player_ids.size(),
		ready_states.size()
	)

	for index in range(amount):
		var player_id: int = int(
			player_ids[index]
		)

		var player_is_ready: bool = bool(
			ready_states[index]
		)

		drawing_ready[player_id] = player_is_ready

	drawing_ready_changed.emit()

	if _are_all_players_ready():
		all_players_ready.emit()


func _are_all_players_ready() -> bool:
	if players.is_empty():
		return false

	for player_key in players:
		var player_is_ready: bool = bool(
			drawing_ready.get(
				player_key,
				false
			)
		)

		if not player_is_ready:
			return false

	return true


# =========================================================
# DISCUSSION OG RUNDER
# =========================================================

func _broadcast_drawings_and_start_discussion() -> void:
	for player_key in submitted_drawings:
		var player_id: int = int(player_key)

		var png_bytes: PackedByteArray = (
			submitted_drawings[player_key]
		)

		Fusion.rpc(
			_receive_drawing_for_discussion,
			player_id,
			png_bytes
		)

	Fusion.rpc(
		_receive_discussion_phase
	)


@rpc("authority", "call_local", "reliable")
func _receive_drawing_for_discussion(
	player_id: int,
	png_bytes: PackedByteArray
) -> void:
	var success: bool = (
		GameData.save_drawing_png(
			player_id,
			png_bytes
		)
	)

	if success:
		_try_open_discussion()


@rpc("authority", "call_local")
func _receive_discussion_phase() -> void:
	discussion_phase_requested = true

	_try_open_discussion()


func _try_open_discussion() -> void:
	if not discussion_phase_requested:
		return

	if discussion_scene_started:
		return

	if GameData.current_round_drawings.size() < players.size():
		return

	discussion_scene_started = true

	get_tree().change_scene_to_file(
		"res://discussion.tscn"
	)


func end_discussion_phase() -> void:
	if not is_host:
		return

	if current_round < MAX_ROUNDS:
		current_round += 1

		Fusion.rpc(
			_receive_next_drawing_round,
			current_round
		)
	else:
		Fusion.rpc(
			_receive_voting_phase
		)


@rpc("authority", "call_local")
func _receive_next_drawing_round(
	next_round: int
) -> void:
	current_round = next_round

	_reset_drawing_round_state()

	get_tree().change_scene_to_file(
		"res://tegne_program.tscn"
	)


@rpc("authority", "call_local")
func _receive_voting_phase() -> void:
	voting_votes.clear()

	voting_result_id = -1
	voting_result_message = ""
	imposter_guess_player_id = -1

	get_tree().change_scene_to_file(
		"res://Voting.tscn"
	)


# =========================================================
# VOTING
# =========================================================

func submit_vote(
	target_player_id: int
) -> void:
	if not players.has(target_player_id):
		return

	var voter_id: int = (
		Fusion.get_local_player_id()
	)

	if is_host:
		_receive_vote_request(
			voter_id,
			target_player_id
		)
	else:
		Fusion.rpc_to(
			Fusion.TARGET_MASTER,
			_receive_vote_request,
			voter_id,
			target_player_id
		)


@rpc("any_peer", "reliable")
func _receive_vote_request(
	voter_id: int,
	target_player_id: int
) -> void:
	if not is_host:
		return

	if not players.has(voter_id):
		return

	if not players.has(target_player_id):
		return

	if not voting_result_message.is_empty():
		return

	voting_votes[voter_id] = target_player_id

	_broadcast_voting_snapshot()

	if voting_votes.size() >= players.size():
		finish_voting()


func _broadcast_voting_snapshot() -> void:
	var voter_ids: Array = []
	var target_ids: Array = []

	for voter_key in voting_votes:
		voter_ids.append(int(voter_key))
		target_ids.append(
			int(voting_votes[voter_key])
		)

	Fusion.rpc(
		_receive_voting_snapshot,
		voter_ids,
		target_ids
	)


@rpc("authority", "call_local")
func _receive_voting_snapshot(
	voter_ids: Array,
	target_ids: Array
) -> void:
	voting_votes.clear()

	var amount: int = mini(
		voter_ids.size(),
		target_ids.size()
	)

	for index in range(amount):
		var voter_id: int = int(
			voter_ids[index]
		)

		var target_id: int = int(
			target_ids[index]
		)

		voting_votes[voter_id] = target_id

	voting_state_changed.emit()


func finish_voting() -> void:
	if not is_host:
		return

	if not voting_result_message.is_empty():
		return

	if voting_votes.is_empty():
		var no_vote_message: String = (
			"Ingen stemmer blev afgivet."
		)

		voting_result_message = no_vote_message

		Fusion.rpc(
			_receive_final_game_result,
			no_vote_message
		)

		return

	_evaluate_votes_on_host()


func _evaluate_votes_on_host() -> void:
	var vote_counts: Dictionary = {}

	for voter_key in voting_votes:
		var target_id: int = int(
			voting_votes[voter_key]
		)

		var current_count: int = int(
			vote_counts.get(
				target_id,
				0
			)
		)

		vote_counts[target_id] = current_count + 1

	var voted_out_id: int = -1
	var highest_vote_count: int = 0
	var is_tie: bool = false

	for target_key in vote_counts:
		var target_id: int = int(target_key)

		var vote_count: int = int(
			vote_counts[target_key]
		)

		if vote_count > highest_vote_count:
			highest_vote_count = vote_count
			voted_out_id = target_id
			is_tie = false
		elif vote_count == highest_vote_count:
			is_tie = true

	if is_tie:
		voted_out_id = -1

	if voted_out_id == -1:
		var tie_message: String = (
			"Afstemningen endte uafgjort. "
			+ "Imposteren overlever."
		)

		voting_result_message = tie_message

		Fusion.rpc(
			_receive_final_game_result,
			tie_message
		)

		return

	if voted_out_id == imposter_id:
		var guess_message: String = (
			"Imposteren blev fundet! "
			+ "Imposteren skal nu gætte ordet."
		)

		voting_result_id = voted_out_id
		voting_result_message = guess_message
		imposter_guess_player_id = imposter_id

		Fusion.rpc(
			_receive_imposter_guess_phase,
			guess_message,
			imposter_id
		)

		return

	var innocent_message: String = (
		"Spiller "
		+ str(voted_out_id)
		+ " blev stemt ud. "
		+ "Imposteren vinder."
	)

	voting_result_id = voted_out_id
	voting_result_message = innocent_message

	Fusion.rpc(
		_receive_final_game_result,
		innocent_message
	)


# =========================================================
# IMPOSTERENS GÆT
# =========================================================

@rpc("authority", "call_local")
func _receive_imposter_guess_phase(
	message: String,
	guessing_player_id: int
) -> void:
	imposter_guess_player_id = guessing_player_id
	voting_result_message = message

	imposter_guess_started.emit(message)


func submit_imposter_guess(
	guess: String
) -> void:
	var cleaned_guess: String = (
		guess.strip_edges()
	)

	if cleaned_guess.is_empty():
		return

	var local_player_id: int = (
		Fusion.get_local_player_id()
	)

	if local_player_id != imposter_guess_player_id:
		return

	if is_host:
		_receive_imposter_guess_request(
			local_player_id,
			cleaned_guess
		)
	else:
		Fusion.rpc_to(
			Fusion.TARGET_MASTER,
			_receive_imposter_guess_request,
			local_player_id,
			cleaned_guess
		)


@rpc("any_peer", "reliable")
func _receive_imposter_guess_request(
	player_id: int,
	guess: String
) -> void:
	if not is_host:
		return

	if player_id != imposter_id:
		return

	var cleaned_guess: String = (
		guess.strip_edges()
	)

	if cleaned_guess.is_empty():
		return

	var normalized_guess: String = (
		_normalize_guess_text(cleaned_guess)
	)

	var normalized_word: String = (
		_normalize_guess_text(current_word)
	)

	print(
		"Guess comparison: [",
		normalized_guess,
		"] vs [",
		normalized_word,
		"]"
	)

	var guess_is_correct: bool = (
		normalized_guess == normalized_word
	)

	var result_message: String = ""

	if guess_is_correct:
		result_message = (
			"Imposteren gættede ordet korrekt "
			+ "og vinder!\n\n"
			+ "Ordet var: "
			+ current_word
		)
	else:
		result_message = (
			"Imposteren gættede forkert.\n"
			+ "De uskyldige vinder!\n\n"
			+ "Det rigtige ord var: "
			+ current_word
		)

	voting_result_message = result_message

	Fusion.rpc(
		_receive_final_game_result,
		result_message
	)


func _normalize_guess_text(
	value: String
) -> String:
	var normalized: String = (
		value.strip_edges()
	)

	normalized = normalized.replace(
		"Æ",
		"æ"
	)

	normalized = normalized.replace(
		"Ø",
		"ø"
	)

	normalized = normalized.replace(
		"Å",
		"å"
	)

	normalized = normalized.to_lower()

	return normalized


@rpc("authority", "call_local")
func _receive_final_game_result(
	result_message: String
) -> void:
	voting_result_message = result_message

	final_game_result.emit(result_message)
	voting_finished.emit()


# =========================================================
# ERROR OG LEAVE
# =========================================================

func _on_connection_failed(error) -> void:
	var message: String = str(error)

	print(
		"Photon connection failed: ",
		message
	)

	join_failed.emit(message)


func leave_room() -> void:
	print("Leaving Photon room")

	if Fusion.has_method("leave_room"):
		Fusion.leave_room()

	players.clear()
	drawing_ready.clear()
	submitted_drawings.clear()
	voting_votes.clear()

	current_round = 1
	current_word = ""
	current_hint = ""
	imposter_id = -1

	voting_result_id = -1
	voting_result_message = ""
	imposter_guess_player_id = -1

	photon_connection_started = false
	photon_connected = false
	room_operation_started = false

	discussion_phase_requested = false
	discussion_scene_started = false

	is_host = false

	if GameData.has_method("clear_all_drawings"):
		GameData.clear_all_drawings()


# =========================================================
# HELPERS
# =========================================================

func _get_display_name_from_user_id(
	user_id: String
) -> String:
	var separator_position: int = user_id.find(
		"__"
	)

	if separator_position == -1:
		return user_id

	return user_id.left(separator_position)


func generate_game_code() -> String:
	var characters: String = (
		"ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
	)

	var code: String = ""

	for i in range(5):
		code += characters[
			randi() % characters.length()
		]

	return code
