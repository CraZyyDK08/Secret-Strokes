extends Node

const ROOM_NAME := "art-imposter-test"
const REGION := "eu"


func _ready() -> void:
	if not Fusion.connected_to_photon.is_connected(_on_connected_to_photon):
		Fusion.connected_to_photon.connect(_on_connected_to_photon)

	if not Fusion.connection_failed.is_connected(_on_connection_failed):
		Fusion.connection_failed.connect(_on_connection_failed)

	if not Fusion.player_joined.is_connected(_on_player_joined):
		Fusion.player_joined.connect(_on_player_joined)

	if not Fusion.player_left.is_connected(_on_player_left):
		Fusion.player_left.connect(_on_player_left)

	var user_id := "test_player_" + str(Time.get_ticks_msec())

	print("Connecting to Photon as: ", user_id)

	# Deferred er vigtigt, når forbindelsen startes fra _ready().
	Fusion.connect_to_photon.call_deferred(
		user_id,
		REGION
	)


func _on_connected_to_photon() -> void:
	print("Connected to Photon!")

	var room_options := FusionRoomOptions.new()
	room_options.max_players = 8

	print("Joining room: ", ROOM_NAME)

	Fusion.join_or_create_room(
		ROOM_NAME,
		room_options
	)


func _on_connection_failed(error) -> void:
	print("Photon connection failed: ", error)


func _on_player_joined(player_id: int, user_id: String) -> void:
	print(
		"Player joined. ID: ",
		player_id,
		" User ID: ",
		user_id
	)


func _on_player_left(player_id: int, is_inactive: bool) -> void:
	print(
		"Player left. ID: ",
		player_id,
		" Inactive: ",
		is_inactive
	)
