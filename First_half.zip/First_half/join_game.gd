extends Control


@onready var menu: VBoxContainer = (
	$CenterContainer/Menu
)

@onready var ip_label: Label = (
	$CenterContainer/Menu/IPLabel
)

@onready var ip_input: LineEdit = (
	$CenterContainer/Menu/IPInput
)

@onready var code_input: LineEdit = (
	$CenterContainer/Menu/CodeInput
)

@onready var join_button: Button = (
	$CenterContainer/Menu/JoinButton
)

@onready var back_button: Button = (
	$CenterContainer/Menu/BackButton
)


var username_input: LineEdit


func _ready() -> void:
	ip_label.hide()
	ip_input.hide()

	_create_username_input()

	join_button.pressed.connect(
		_on_join_pressed
	)

	back_button.pressed.connect(
		_on_back_pressed
	)

	Network.join_failed.connect(
		_on_join_failed
	)


func _create_username_input() -> void:
	username_input = LineEdit.new()

	username_input.name = "UsernameInput"
	username_input.placeholder_text = "Skriv dit username"
	username_input.max_length = 20
	username_input.custom_minimum_size = Vector2(
		0,
		55
	)

	username_input.alignment = (
		HORIZONTAL_ALIGNMENT_CENTER
	)

	menu.add_child(username_input)
	menu.move_child(username_input, 1)


func _get_username() -> String:
	var username: String = (
		username_input.text.strip_edges()
	)

	if username.is_empty():
		return "Player"

	return username.left(20)


func _on_join_pressed() -> void:
	var code: String = (
		code_input.text.strip_edges().to_upper()
	)

	if code.length() != 5:
		print(
			"Game code must be exactly 5 characters"
		)

		return

	Network.join_game(
		_get_username(),
		code
	)

	get_tree().change_scene_to_file(
		"res://lobby.tscn"
	)


func _on_join_failed(message: String) -> void:
	print(
		"Could not join game: ",
		message
	)


func _on_back_pressed() -> void:
	get_tree().change_scene_to_file(
		"res://main_menu.tscn"
	)
