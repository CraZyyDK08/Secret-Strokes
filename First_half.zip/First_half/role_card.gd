extends Control


@onready var role_label: Label = $RoleLabel
@onready var symbol_image: TextureRect = $SymbolImage
@onready var hint_label: Label = $HintLabel
@onready var countdown_label: Label = $CountdownLabel
@onready var timer: Timer = $Timer


var time_left: int = 5


func _ready() -> void:
	show_role()

	time_left = 5
	countdown_label.text = str(time_left)

	timer.wait_time = 1.0
	timer.one_shot = false
	timer.start()


func show_role() -> void:
	if RoleGameManager.is_imposter:
		role_label.text = "IMPOSTER"

		symbol_image.visible = false

		hint_label.visible = true
		hint_label.text = (
			"HINT\n\n"
			+ RoleGameManager.current_hint
		)
	else:
		role_label.text = "INNO"

		symbol_image.visible = false

		hint_label.visible = true
		hint_label.text = (
			"DIT ORD\n\n"
			+ RoleGameManager.current_word
		)


func _on_timer_timeout() -> void:
	time_left -= 1
	countdown_label.text = str(time_left)

	if time_left <= 0:
		timer.stop()

		# Kun hosten må starte næste fase.
		# Hostens besked sender alle spillere videre.
		if Network.is_host:
			Network.start_drawing_phase()
