extends Control


@onready var drawing_canvas = $DrawingCanvas

@onready var pencil_button: Button = $PencilButton
@onready var eraser_button: Button = $EraserButton
@onready var clear_button: Button = $ClearButton

@onready var color_buttons: Array[Node] = (
	$ColorPanel.get_children()
)

@onready var size_slider: HSlider = $SizeSlider

@onready var undo_button: Button = $UndoButton
@onready var redo_button: Button = $RedoButton


const DRAWING_TIME: int = 90


var done_button: Button
var timer_label: Label
var round_timer: Timer

var time_left: int = DRAWING_TIME
var local_drawing_ready: bool = false

var selected_color_button: Button = null
var normal_color_styles: Dictionary = {}


var colors: Array[Color] = [
	Color.BLACK,
	Color.WHITE,
	Color.RED,
	Color.GREEN,
	Color.BLUE,
	Color.YELLOW,
	Color.ORANGE,
	Color.PURPLE,
	Color.PINK,
	Color.BROWN,
	Color.CYAN,
	Color.GRAY
]


func _ready() -> void:
	pencil_button.pressed.connect(
		_on_pencil_button_pressed
	)

	eraser_button.pressed.connect(
		_on_eraser_button_pressed
	)

	clear_button.pressed.connect(
		_on_clear_button_pressed
	)

	undo_button.pressed.connect(
		_on_undo_button_pressed
	)

	redo_button.pressed.connect(
		_on_redo_button_pressed
	)

	Network.all_players_ready.connect(
		_on_all_players_ready
	)

	size_slider.min_value = 1
	size_slider.max_value = 50
	size_slider.step = 1

	size_slider.value = (
		GameData.get_brush_size()
	)

	size_slider.value_changed.connect(
		_on_size_changed
	)

	drawing_canvas.set_brush_size(
		GameData.get_brush_size()
	)

	setup_color_buttons()
	setup_ui_and_timer()


func setup_color_buttons() -> void:
	for i in range(color_buttons.size()):
		if i >= colors.size():
			continue

		var button: Button = (
			color_buttons[i] as Button
		)

		if button == null:
			continue

		var color: Color = colors[i]

		var normal_style: StyleBoxFlat = (
			StyleBoxFlat.new()
		)

		normal_style.bg_color = color

		normal_style.corner_radius_top_left = 6
		normal_style.corner_radius_top_right = 6
		normal_style.corner_radius_bottom_left = 6
		normal_style.corner_radius_bottom_right = 6

		normal_color_styles[button] = normal_style

		button.add_theme_stylebox_override(
			"normal",
			normal_style
		)

		button.add_theme_stylebox_override(
			"hover",
			normal_style
		)

		button.add_theme_stylebox_override(
			"pressed",
			normal_style
		)

		button.custom_minimum_size = Vector2(
			40,
			40
		)

		button.pressed.connect(
			_on_color_button_pressed.bind(
				button,
				color
			)
		)

	if not color_buttons.is_empty():
		var first_button: Button = (
			color_buttons[0] as Button
		)

		if first_button != null:
			drawing_canvas.set_color(colors[0])
			_select_color_button(first_button)


func _on_color_button_pressed(
	button: Button,
	color: Color
) -> void:
	if local_drawing_ready:
		return

	drawing_canvas.set_color(color)
	_select_color_button(button)


func _select_color_button(
	button: Button
) -> void:
	if selected_color_button != null:
		_restore_normal_color_button(
			selected_color_button
		)

	selected_color_button = button

	if not normal_color_styles.has(button):
		return

	var base_style: StyleBoxFlat = (
		normal_color_styles[button]
		as StyleBoxFlat
	)

	if base_style == null:
		return

	var selected_style: StyleBoxFlat = (
		base_style.duplicate()
		as StyleBoxFlat
	)

	selected_style.border_width_left = 4
	selected_style.border_width_top = 4
	selected_style.border_width_right = 4
	selected_style.border_width_bottom = 4

	selected_style.border_color = (
		_get_selection_border_color(
			base_style.bg_color
		)
	)

	button.add_theme_stylebox_override(
		"normal",
		selected_style
	)

	button.add_theme_stylebox_override(
		"hover",
		selected_style
	)

	button.add_theme_stylebox_override(
		"pressed",
		selected_style
	)


func _restore_normal_color_button(
	button: Button
) -> void:
	if not normal_color_styles.has(button):
		return

	var normal_style: StyleBoxFlat = (
		normal_color_styles[button]
		as StyleBoxFlat
	)

	if normal_style == null:
		return

	button.add_theme_stylebox_override(
		"normal",
		normal_style
	)

	button.add_theme_stylebox_override(
		"hover",
		normal_style
	)

	button.add_theme_stylebox_override(
		"pressed",
		normal_style
	)


func _get_selection_border_color(
	background_color: Color
) -> Color:
	var brightness: float = (
		background_color.r * 0.299
		+ background_color.g * 0.587
		+ background_color.b * 0.114
	)

	if brightness > 0.65:
		return Color(
			0.05,
			0.05,
			0.05,
			1.0
		)

	return Color.WHITE


func _on_pencil_button_pressed() -> void:
	if local_drawing_ready:
		return

	drawing_canvas.set_pencil()


func _on_eraser_button_pressed() -> void:
	if local_drawing_ready:
		return

	drawing_canvas.set_eraser()


func _on_clear_button_pressed() -> void:
	if local_drawing_ready:
		return

	drawing_canvas.clear_canvas()


func _on_undo_button_pressed() -> void:
	if local_drawing_ready:
		return

	drawing_canvas.undo()


func _on_redo_button_pressed() -> void:
	if local_drawing_ready:
		return

	drawing_canvas.redo()


func _on_size_changed(
	value: float
) -> void:
	if local_drawing_ready:
		return

	var new_size: int = int(value)

	drawing_canvas.set_brush_size(
		new_size
	)

	GameData.set_brush_size(
		new_size
	)


func setup_ui_and_timer() -> void:
	done_button = Button.new()
	done_button.text = "FÆRDIG / KLAR"
	done_button.position = Vector2(20, 320)
	done_button.size = Vector2(150, 50)

	done_button.pressed.connect(
		_on_done_button_pressed
	)

	add_child(done_button)

	timer_label = Label.new()
	timer_label.text = (
		"Tid: "
		+ str(time_left)
	)

	timer_label.position = Vector2(
		150,
		10
	)

	timer_label.add_theme_font_size_override(
		"font_size",
		24
	)

	add_child(timer_label)

	round_timer = Timer.new()
	round_timer.wait_time = 1.0
	round_timer.one_shot = false

	round_timer.timeout.connect(
		_on_round_timer_timeout
	)

	add_child(round_timer)
	round_timer.start()


func _on_round_timer_timeout() -> void:
	time_left -= 1

	timer_label.text = (
		"Tid: "
		+ str(time_left)
	)

	if time_left > 0:
		return

	round_timer.stop()

	if not local_drawing_ready:
		_set_local_ready(true)


func _on_done_button_pressed() -> void:
	if local_drawing_ready:
		_set_local_ready(false)
	else:
		_set_local_ready(true)


func _set_local_ready(
	new_ready_state: bool
) -> void:
	local_drawing_ready = new_ready_state

	if local_drawing_ready:
		Network.submit_drawing(
			drawing_canvas.canvas_image
		)

		done_button.text = "IKKE KLAR"

		done_button.modulate = Color(
			1.0,
			0.35,
			0.35
		)

		drawing_canvas.mouse_filter = (
			Control.MOUSE_FILTER_IGNORE
		)

		# Timeren stoppes ikke her.
		# Den fortsætter med at tælle ned.
	else:
		if time_left <= 0:
			return

		Network.set_local_drawing_ready(false)

		done_button.text = "FÆRDIG / KLAR"

		done_button.modulate = Color(
			0.35,
			1.0,
			0.35
		)

		drawing_canvas.mouse_filter = (
			Control.MOUSE_FILTER_STOP
		)


func _on_all_players_ready() -> void:
	print(
		"All players are ready"
	)
