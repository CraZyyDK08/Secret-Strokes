extends Control


@onready var menu: VBoxContainer = $Menu

@onready var create_game_button: Button = (
	$Menu/CreateGameButton
)

@onready var join_game_button: Button = (
	$Menu/JoinGameButton
)

@onready var quit_button: Button = (
	$Menu/QuitButton
)


var username_input: LineEdit


func _ready() -> void:
	_create_username_input()

	create_game_button.pressed.connect(
		_on_create_game_pressed
	)

	join_game_button.pressed.connect(
		_on_join_game_pressed
	)

	quit_button.pressed.connect(
		_on_quit_pressed
	)


func _create_username_input() -> void:
	username_input = LineEdit.new()

	username_input.name = "UsernameInput"
	username_input.placeholder_text = "Skriv dit username"
	username_input.max_length = 20
	username_input.custom_minimum_size = Vector2(
		0,
		55
	)

	username_input.alignment = (
		HORIZONTAL_ALIGNMENT_CENTER
	)

	menu.add_child(username_input)
	menu.move_child(username_input, 1)


func _get_username() -> String:
	var username: String = (
		username_input.text.strip_edges()
	)

	if username.is_empty():
		return "Player"

	return username.left(20)


func _on_create_game_pressed() -> void:
	Network.create_game(
		_get_username()
	)

	get_tree().change_scene_to_file(
		"res://lobby.tscn"
	)


func _on_join_game_pressed() -> void:
	get_tree().change_scene_to_file(
		"res://join_game.tscn"
	)


func _on_quit_pressed() -> void:
	get_tree().quit()
