extends Control


@onready var main_vbox: VBoxContainer = (
	$VBoxContainer
)

@onready var title_label: Label = (
	$VBoxContainer/TitleLabel
)

@onready var subtitle_label: Label = (
	$VBoxContainer/SubtitleLabel
)

@onready var timer_label: Label = (
	$VBoxContainer/TimerLabel
)

@onready var scroll_container: ScrollContainer = (
	$VBoxContainer/ScrollContainer
)

@onready var player_grid: GridContainer = (
	$VBoxContainer/ScrollContainer/PlayerGrid
)

@onready var guess_panel: PanelContainer = (
	$GuessPanel
)

@onready var word_input: LineEdit = (
	$GuessPanel/VBoxContainer/WordInput
)

@onready var submit_guess_button: Button = (
	$GuessPanel/VBoxContainer/SubmitGuessButton
)

@onready var result_panel: PanelContainer = (
	$ResultPanel
)

@onready var result_label: Label = (
	$ResultPanel/VBoxContainer/ResultLabel
)

@onready var restart_button: Button = (
	$ResultPanel/VBoxContainer/RestartButton
)

@onready var timer: Timer = $Timer


const VOTING_TIME: int = 90
const TOTAL_ROUNDS: int = 3


var time_left: int = VOTING_TIME
var has_voted: bool = false

var gallery_panel: PanelContainer
var gallery_title: Label
var gallery_grid: GridContainer
var gallery_back_button: Button


func _ready() -> void:
	title_label.text = "AFSTEMNING"

	subtitle_label.text = (
		"Klik på et profilbillede for at se tegninger"
	)

	timer_label.text = (
		"Tid tilbage: "
		+ str(time_left)
	)

	guess_panel.visible = false
	result_panel.visible = false
	restart_button.visible = false

	submit_guess_button.pressed.connect(
		_on_submit_guess_pressed
	)

	Network.voting_state_changed.connect(
		_on_voting_state_changed
	)

	Network.imposter_guess_started.connect(
		_on_imposter_guess_started
	)

	Network.final_game_result.connect(
		_on_final_game_result
	)

	timer.wait_time = 1.0
	timer.one_shot = false

	timer.timeout.connect(
		_on_timer_timeout
	)

	_create_gallery_ui()
	setup_voting_cards()

	timer.start()


func setup_voting_cards() -> void:
	for child in player_grid.get_children():
		child.queue_free()

	var player_ids: Array = Network.players.keys()
	player_ids.sort()

	if player_ids.is_empty():
		var empty_label: Label = Label.new()

		empty_label.text = (
			"Venter på spillere..."
		)

		player_grid.add_child(
			empty_label
		)

		return

	if player_ids.size() <= 4:
		player_grid.columns = 2
	else:
		player_grid.columns = 3

	for player_key in player_ids:
		var player_id: int = int(player_key)

		var visible_name: String = (
			_get_display_name(player_id)
		)

		var card: PanelContainer = (
			PanelContainer.new()
		)

		card.custom_minimum_size = Vector2(
			300,
			300
		)

		var card_style: StyleBoxFlat = (
			StyleBoxFlat.new()
		)

		card_style.bg_color = Color(
			0.15,
			0.17,
			0.23,
			0.95
		)

		card_style.corner_radius_top_left = 12
		card_style.corner_radius_top_right = 12
		card_style.corner_radius_bottom_left = 12
		card_style.corner_radius_bottom_right = 12

		card_style.content_margin_left = 12
		card_style.content_margin_top = 12
		card_style.content_margin_right = 12
		card_style.content_margin_bottom = 12

		card.add_theme_stylebox_override(
			"panel",
			card_style
		)

		var vbox: VBoxContainer = (
			VBoxContainer.new()
		)

		var profile_button: Button = (
			_create_profile_button(
				player_id,
				visible_name
			)
		)

		profile_button.pressed.connect(
			_show_player_gallery.bind(player_id)
		)

		var vote_button: Button = Button.new()

		vote_button.text = (
			"STEM PÅ "
			+ visible_name
		)

		vote_button.custom_minimum_size = Vector2(
			0,
			55
		)

		vote_button.pressed.connect(
			_cast_vote.bind(player_id)
		)

		vbox.add_child(profile_button)
		vbox.add_child(vote_button)

		card.add_child(vbox)
		player_grid.add_child(card)


func _create_profile_button(
	player_id: int,
	visible_name: String
) -> Button:
	var profile_button: Button = Button.new()

	profile_button.text = (
		visible_name
		+ "\n\n"
		+ "Klik for at se tegninger"
	)

	profile_button.custom_minimum_size = Vector2(
		0,
		210
	)

	var profile_color: Color = (
		_get_profile_color(player_id)
	)

	var normal_style: StyleBoxFlat = (
		StyleBoxFlat.new()
	)

	normal_style.bg_color = profile_color
	normal_style.corner_radius_top_left = 12
	normal_style.corner_radius_top_right = 12
	normal_style.corner_radius_bottom_left = 12
	normal_style.corner_radius_bottom_right = 12

	var hover_style: StyleBoxFlat = (
		normal_style.duplicate()
		as StyleBoxFlat
	)

	hover_style.bg_color = (
		profile_color.lightened(0.15)
	)

	var pressed_style: StyleBoxFlat = (
		normal_style.duplicate()
		as StyleBoxFlat
	)

	pressed_style.bg_color = (
		profile_color.darkened(0.15)
	)

	profile_button.add_theme_stylebox_override(
		"normal",
		normal_style
	)

	profile_button.add_theme_stylebox_override(
		"hover",
		hover_style
	)

	profile_button.add_theme_stylebox_override(
		"pressed",
		pressed_style
	)

	return profile_button


func _get_profile_color(
	player_id: int
) -> Color:
	var colors: Array[Color] = [
		Color(0.08, 0.08, 0.08),
		Color(0.18, 0.32, 0.55),
		Color(0.50, 0.22, 0.25),
		Color(0.22, 0.45, 0.30),
		Color(0.45, 0.30, 0.58),
		Color(0.55, 0.38, 0.18)
	]

	return colors[
		abs(player_id) % colors.size()
	]


func _get_display_name(
	player_id: int
) -> String:
	var base_name: String = str(
		Network.players.get(
			player_id,
			"Ukendt spiller"
		)
	)

	var matching_ids: Array = []

	for player_key in Network.players:
		var current_player_id: int = int(
			player_key
		)

		var current_name: String = str(
			Network.players[player_key]
		)

		if current_name == base_name:
			matching_ids.append(
				current_player_id
			)

	matching_ids.sort()

	if matching_ids.size() <= 1:
		return base_name

	return (
		base_name
		+ " ["
		+ str(matching_ids.find(player_id) + 1)
		+ "]"
	)


func _create_gallery_ui() -> void:
	gallery_panel = PanelContainer.new()

	gallery_panel.set_anchors_preset(
		Control.PRESET_FULL_RECT
	)

	gallery_panel.offset_left = 40
	gallery_panel.offset_top = 40
	gallery_panel.offset_right = -40
	gallery_panel.offset_bottom = -40

	gallery_panel.z_index = 100
	gallery_panel.visible = false

	var gallery_vbox: VBoxContainer = (
		VBoxContainer.new()
	)

	gallery_title = Label.new()
	gallery_title.horizontal_alignment = (
		HORIZONTAL_ALIGNMENT_CENTER
	)

	gallery_back_button = Button.new()
	gallery_back_button.text = (
		"Tilbage til afstemning"
	)

	gallery_back_button.pressed.connect(
		_hide_player_gallery
	)

	var gallery_scroll: ScrollContainer = (
		ScrollContainer.new()
	)

	gallery_scroll.size_flags_vertical = (
		Control.SIZE_EXPAND_FILL
	)

	gallery_grid = GridContainer.new()
	gallery_grid.columns = 3

	gallery_scroll.add_child(
		gallery_grid
	)

	gallery_vbox.add_child(
		gallery_title
	)

	gallery_vbox.add_child(
		gallery_back_button
	)

	gallery_vbox.add_child(
		gallery_scroll
	)

	gallery_panel.add_child(
		gallery_vbox
	)

	add_child(gallery_panel)


func _show_player_gallery(
	player_id: int
) -> void:
	gallery_title.text = (
		"Tegninger fra "
		+ _get_display_name(player_id)
	)

	for child in gallery_grid.get_children():
		child.queue_free()

	for round_number in range(
		1,
		TOTAL_ROUNDS + 1
	):
		var round_label: Label = Label.new()

		round_label.text = (
			"RUNDE "
			+ str(round_number)
		)

		round_label.horizontal_alignment = (
			HORIZONTAL_ALIGNMENT_CENTER
		)

		var round_vbox: VBoxContainer = (
			VBoxContainer.new()
		)

		var texture: Texture2D = (
			GameData.get_player_drawing(
				player_id,
				round_number
			)
		)

		if texture != null:
			var image_rect: TextureRect = (
				TextureRect.new()
			)

			image_rect.texture = texture
			image_rect.expand_mode = (
				TextureRect.EXPAND_IGNORE_SIZE
			)

			image_rect.stretch_mode = (
				TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			)

			image_rect.custom_minimum_size = Vector2(
				270,
				220
			)

			round_vbox.add_child(
				image_rect
			)
		else:
			var no_drawing: Label = Label.new()

			no_drawing.text = (
				"Ingen tegning"
			)

			no_drawing.custom_minimum_size = Vector2(
				270,
				220
			)

			no_drawing.horizontal_alignment = (
				HORIZONTAL_ALIGNMENT_CENTER
			)

			round_vbox.add_child(
				no_drawing
			)

		round_vbox.add_child(
			round_label
		)

		gallery_grid.add_child(
			round_vbox
		)

	gallery_panel.visible = true
	gallery_panel.move_to_front()


func _hide_player_gallery() -> void:
	gallery_panel.visible = false


func _cast_vote(
	target_player_id: int
) -> void:
	if has_voted:
		return

	has_voted = true

	Network.submit_vote(
		target_player_id
	)

	subtitle_label.text = (
		"Du stemte på "
		+ _get_display_name(target_player_id)
	)

	_set_vote_buttons_disabled(true)


func _set_vote_buttons_disabled(
	disabled: bool
) -> void:
	for card_node in player_grid.get_children():
		var card: PanelContainer = (
			card_node as PanelContainer
		)

		if card == null:
			continue

		var card_vbox: VBoxContainer = (
			card.get_child(0) as VBoxContainer
		)

		if card_vbox == null:
			continue

		var button_index: int = (
			card_vbox.get_child_count() - 1
		)

		var vote_button: Button = (
			card_vbox.get_child(button_index)
			as Button
		)

		if vote_button != null:
			vote_button.disabled = disabled


func _on_voting_state_changed() -> void:
	if has_voted:
		return

	subtitle_label.text = (
		"Stemmer modtaget: "
		+ str(Network.voting_votes.size())
		+ " / "
		+ str(Network.players.size())
	)


func _on_timer_timeout() -> void:
	time_left -= 1

	timer_label.text = (
		"Tid tilbage: "
		+ str(time_left)
	)

	if time_left > 0:
		return

	timer.stop()

	if Network.is_host:
		Network.finish_voting()


func _on_imposter_guess_started(
	message: String
) -> void:
	timer.stop()

	main_vbox.visible = false
	result_panel.visible = true

	var local_player_id: int = (
		Fusion.get_local_player_id()
	)

	if local_player_id == Network.imposter_guess_player_id:
		guess_panel.visible = true
		word_input.clear()
		submit_guess_button.disabled = false
	else:
		result_label.text = (
			message
			+ "\n\nVenter på imposteren..."
		)


func _on_submit_guess_pressed() -> void:
	var guess: String = (
		word_input.text.strip_edges()
	)

	if guess.is_empty():
		return

	submit_guess_button.disabled = true

	Network.submit_imposter_guess(
		guess
	)


func _on_final_game_result(
	message: String
) -> void:
	timer.stop()

	main_vbox.visible = false
	guess_panel.visible = false
	result_panel.visible = true

	result_label.text = message
