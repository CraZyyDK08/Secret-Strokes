extends Node


var is_imposter: bool = false
var current_word: String = ""
var current_hint: String = ""


func _ready() -> void:
	print(
		"RoleGameManager loaded. apply_server_role available: ",
		has_method("apply_server_role")
	)


func apply_server_role(
	new_is_imposter: bool,
	new_word: String,
	new_hint: String
) -> void:
	is_imposter = new_is_imposter
	current_word = new_word
	current_hint = new_hint

	print("Local role updated")
	print("Is imposter: ", is_imposter)
	print("Word: ", current_word)
	print("Hint: ", current_hint)
